//import Neuron
import java.util.ArrayList;

public class Layer {
	public int H;
	public int D;
	public ArrayList<Neuron> neurons = new ArrayList<Neuron>();

	public Layer(int d,int h, float[] x_inputs){
		this.H = h;
		this.D = d;
		Init_Neurons(x_inputs);
	}

	public void Init_Neurons(float[] x_inputs){
		for (int h=0;h<H;h++) {
			neurons.add(new Neuron(D,x_inputs));
		}
	}

	public void nice_print(){
		for (int h=0;h<H;h++) {
			System.out.println(neurons.get(h).get_val());
		}	
	}

	public float[] forward_pass(){
		float[] outputs= new float[H];
		for (int h=0;h<H;h++) {
			outputs[h]=neurons.get(h).calculate_u();
		}	
		return outputs;		
	}
}