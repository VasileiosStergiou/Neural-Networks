import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.ArrayList;
import java.util.Random;
import java.lang.Math;

public class Main {
  public static void main(String[] args) {
    ArrayList<float[]> test_set = parse_Data("test_set.txt");
    ArrayList<float[]> training_set = parse_Data("training_set.txt");

    int d = 2;//training_set.size();
    int h1 = 3;
    int h2 = 3;
    int k = 2;

    float[] temp_data={1.0f,2.0f};
    Layer H1 = new Layer(d,h1,temp_data);
    temp_data=H1.forward_pass();
    
    Layer H2 = new Layer(h1,h2,temp_data);
    temp_data=H2.forward_pass();
    
    Layer Output_Layer = new Layer(h2,k,temp_data);
    temp_data=Output_Layer.forward_pass();

    for (float x : temp_data) {
      System.out.println(step_act(x));
      //System.out.println(x);
    }
    //H1.nice_print();
    // ruthmos mathisis
    float n = 0.1f;

    //float min = -1.0f;
    //float max = 1.0f;

    //float [] w = initialize_weights(d,min,max);

    //float [] x_k = select_random_input(training_set,0,training_set.size());

    //System.out.println(get_neuron_output(training_set,w));
  }

  static float [] select_random_input(ArrayList<float[]> training_set,int minimum,int maximum){
    Random random_input = new Random();
    int n = maximum - minimum + 1;
    int k = Math.abs(random_input.nextInt()) % n;
    return training_set.get(k);
  }

  static float step_act(float x){
    if(x<0){
      return -1.0f;
    }
    return 1.0f;
  }

/*  static float sigmoid(float a,float x){
    return 1.0f/(float)(1.0f+Math.exp(-a*x));
  }*/

  static ArrayList<float[]> parse_Data(String filename){
    ArrayList<float[]> all_data = new ArrayList<float[]>();
    float[] point;
    try {
      File myObj = new File(filename);
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        point= new float[3];
        String[] data = myReader.nextLine().split(",");
        for(int i=0;i<3;i++){
          //System.out.println(Float.parseFloat(data[i]));
          point[i]=Float.parseFloat(data[i]);
        }
        all_data.add(point);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }  
    return all_data;
  }
}