import java.util.Random;
import java.lang.Math;

public class Neuron {
	public int D;
	public float[] weights;
	public float[] x;

	public Neuron(int d, float[] x_inputs){
		this.D=d+1;
		this.weights = new float[this.D];
		this.x = new float[this.D];
		Init_weights();
		Init_inputs(x_inputs);
	}

	public int get_val(){
		return D;
	}

	public void Init_weights(){
		Random random_weigth = new Random();

		// w0 =1 panta leei stis diafanies
		//System.out.println(weights.length);
		weights[0] = 1.0f;

		for (int i =1;i< D;i++){
	 		float w = random_weigth.nextFloat() * 2 - 1 ; //2=(max - min) + min
 	  		//System.out.println("w "+w);
	  		weights[i] = w;
		}
	}

	public void Init_inputs(float[] x_inputs){
		x[0] = 1.0f;

		for (int i =1;i< D;i++){
	  		x[i] = x_inputs[i-1];
		}
	}

	public float calculate_u(){
		float w_sum=weights[0]*x[0];
		for (int i=1;i<D;i++) {
			w_sum+=weights[i]*x[i];
		}
		return activation_func(1.0f,w_sum);
	}

	public float activation_func(float a,float x){
		return (float)(Math.exp(a*x)-Math.exp(-a*x))/(float)(Math.exp(a*x)+Math.exp(-a*x));
	}
}