import random as r
import matplotlib.pyplot as plt
import numpy as np

def make_data_set(N):
	C = []

	for i in range(N):
		data = [r.uniform(-1,1),r.uniform(-1,1)]
		if (data[0] - 0.5)**2 + (data[1] - 0.5)**2 <0.16 or (data[0] + 0.5)**2 + (data[1] + 0.5)**2 <0.16:
			C.append([data,0])
		elif (data[0] - 0.5)**2 + (data[1] + 0.5)**2 <0.16 or (data[0] + 0.5)**2 + (data[1] - 0.5)**2 <0.16:
			C.append([data,1])
		elif data[0] >=0 and data[1] >=0 or data[0] <=0 and data[1] <=0:
			C.append([data,2])
		else:
			C.append([data,3])

	return C

def change_group(C):
	for data in C:
		ids = [i for i in range(4)]
		ids.pop(data[1])
		probability = r.uniform(0,1)
		if probability <= 0.1:
			new_set = r.randint(0,2)
			data[1] = ids[new_set]


def plot_data(C):
	x = [[],[],[],[]]
	y = [[],[],[],[]]

	for data in C:
		x[data[1]].append(data[0][0])
		y[data[1]].append(data[0][1])

	plt.figure()
	plt.scatter(x[0],y[0])
	plt.scatter(x[1],y[1])
	plt.scatter(x[2],y[2])
	plt.scatter(x[3],y[3])
	plt.show()

def write_to_file(C,name):
	s1 = open(name+".txt",'w')

	for data in C:
		s1.write(str(data[0][0])+','+str(data[0][1])+','+str(data[1])+'\n')
	s1.close()

N=4000

S1 = make_data_set(N)

change_group(S1)

plot_data(S1)

write_to_file(S1,'training_set')

S2 = make_data_set(N)
write_to_file(S2,'test_set')




