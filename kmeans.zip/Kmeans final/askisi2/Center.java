import java.util.ArrayList;

class Center{

	// The current position of the center
	public float [] position = new float[2];

	// The previous position of the center
	public float [] previous_position = {0.0f,0.0f};

	// The points that are in its group
	public ArrayList<float[]> group = new ArrayList<float[]>();

	public Center(float[] position){
		this.position[0] = position[0];
		this.position[1] = position[1];
	}

	// Get the position of tthe center
	public float [] get_position(){
		return position;
	}

	// Add a point in its group
	public void add_point(float[] point){
		this.group.add(point);
	}

	// Calculate the new position of the center
	// By getting the avarage x,y from the points in its group
	// If the group has no points in it,
	// Keep its previous x,y values
	public void calculate_new_center(){
		float new_x = 0.0f;
		float new_y = 0.0f;

		this.previous_position[0] = position[0];
		this.previous_position[1] = position[1];

		for (float [] point : group){
			new_x += point[0];
			new_y += point[1];
		}

		if (group.size() != 0){
			this.position[0] = new_x/group.size();
			this.position[1] = new_y/group.size();
		}

	}

	// calculate the distance between the previous position
	// of the center and its current one
	public float get_distance(){

		float x = position[0] - previous_position[0];
		float y = position[1] - previous_position[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	// Get the distance between a point and the center
	public float get_error_distance(float [] point, float [] center){

		float x = point[0] - center[0];
		float y = point[1] - center[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	// Get the total error from the points in the
	// gropu of the center
	public float calculate_total_group_error(){
		float error = 0.0f;
		for (float [] point:group){
			error+= get_error_distance(point,position);
		}
		return error;
	}

	// Empty the group
	public void clear_group(){
		this.group = new ArrayList<float[]>();
	}
}