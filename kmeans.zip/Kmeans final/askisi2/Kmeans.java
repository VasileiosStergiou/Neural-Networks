import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.ArrayList;
import java.util.Random;
import java.lang.Math;
import java.io.FileWriter;  // Write the File class
import java.io.IOException;  // Import the IOException class to handle errors

class Kmeans{
	// The name of the file that contains the input dataset
	public String filename;

	// The number of centers that the algorithm uses
	public int k;

	//the treshold that checks for the end of the algorithm
	public float dist_error;

	// How many times the K-Means algorithm runs
	public int iterations;

	// The best centers of each iteration
	public ArrayList<Center> best_centers = new ArrayList<Center>();
	
	public Kmeans(String filename,int k,float dist_error,int iterations){
		this.filename = filename;
		this.k = k;
		this.dist_error = dist_error; 
		this.iterations = iterations;
	}

	public void start() {
		// Load the dataset
		ArrayList<float[]> data_set = parse_Data(filename);
		float best_score=Float.POSITIVE_INFINITY;
		float total_error=0.0f;

		// Keep track of how many centers have moved
		// The algorithm ends when none of the centers have moved
		int centers_moved;

		// The K selected centers from the dataset
		ArrayList<Center> centers;
		System.out.println("\nFOR K="+k);
		for (int iteration =0;iteration <20;iteration ++){

			// Select K centers from the dataset
			centers = init_centers(k,data_set);

			// In order to initialize the algorithm, consider that
			// at least one center has moved
			centers_moved =1;

			while (centers_moved >0){

				// For each of the center, clear its group
				for (Center c : centers){
					c.clear_group();
				}

				for (float[] point : data_set){
					
					// For each point in the data set
					// Find its distance from each of the K centers
					float[] distances = new float[k];

					for (int i =0; i< k; i++){
						distances[i] = get_distance(point,centers.get(i).get_position());
					}

					// Append the point to the group that the distance from its
					// center has the minimum value
					centers.get(minValue(distances)).add_point(point);
				}

				centers_moved =0;
				for (Center c : centers){
					// Find the new position of each center
					c.calculate_new_center();

					// If it is above the threshold,
					// consider that the center moved
					if (c.get_distance() >= dist_error){
						centers_moved+=1;
					}
				}
			}

			// Calculate the total groupin error
			total_error=0.0f;
			for (Center c : centers){
				total_error += c.calculate_total_group_error();
			}

			System.out.println("ITERATION: "+(iteration+1)+" iteration Error="+total_error);

			// If the current grouping error is lower than the previous
			// Set the current one as the best, along with its centers
			if(total_error<best_score){
				best_score=total_error;
				best_centers=centers;
			}

		}
		System.out.println("Best score="+best_score);
		System.out.println("Best centers:");
		for(Center c:best_centers){
			System.out.println(c.position[0]+","+c.position[1]);
		}
		System.out.println("FINISHED");
	}

	// For each distance between the current point and the K centers
	// Find the minimum one and which center possesses it
	public int minValue(float[] distances) {
		float min = distances[0];
		int pos = 0;
		for (int i = 0; i < distances.length; i++) {
				if (distances[i] < min) {
						min = distances[i];
						pos = i;
				}
		}
		return pos;
}
	// Calculate distance between a point and a center
	public float get_distance(float [] point, float [] center){

		float x = point[0] - center[0];
		float y = point[1] - center[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	// From the dataset, select k random centers
	public ArrayList<Center> init_centers(int k,ArrayList<float[]> data_set){

		ArrayList<Center> centers = new ArrayList<Center>();

		for (int i =0;i < k ;i++){
				Random random = new Random();
				int random_center = random.nextInt(data_set.size());
				centers.add(new Center(data_set.get(random_center)));
			}
			return centers;
	 }

	// Load the data from the file
	public ArrayList<float[]> parse_Data(String filename){
		ArrayList<float[]> all_data = new ArrayList<float[]>();
		float[] point;
		try {
			File myObj = new File(filename);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				point= new float[2];
				String[] data = myReader.nextLine().split(",");
				for(int i=0;i<2;i++){
					point[i]=Float.parseFloat(data[i]);
				}
				all_data.add(point);
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}  
		return all_data;
	}

	// For each of the best centers, write it in a JSON file
	// Along with the elements in its group
	public void write2file(){
		try {
			FileWriter myWriter = new FileWriter("filename_"+k+".json");
			myWriter.write("[");
			String values="";
			for(Center center:best_centers){			
				values+="\n\t{\n";
				values+=" \t\t\"center\":";
				values+="["+center.get_position()[0]+","+center.get_position()[1]+"],\n";
				values+=" \t\t\"group\":";
				values+="[";
				for(float[] point: center.group){
					values+="["+point[0]+","+point[1]+"],";	
				}
				values = values.substring(0, values.length() - 1);
				values+="]\n";
				values+="\t},";
			}
			values = values.substring(0, values.length() - 1);
			values+="\n]";
			myWriter.write(values);
			myWriter.close();
			System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
}