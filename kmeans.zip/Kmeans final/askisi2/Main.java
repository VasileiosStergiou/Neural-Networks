class Main{
	public static void main(String[] args) {
		//int k=5;
		//The centers that the K-Means algorithm is executed
		int[] k= {3,5,7,9,11,13};		
		String file_name="set.txt";

		// For each center, its the threshold that indicates its movement
		// Although the the algorithm ends when all centers heven't moved
		// it takes many loops to happen, so a threshold is set for that reason
		float distance_error=0.0001f;
		int iterations=20;

		for(int m:k){
			Kmeans kmeans = new Kmeans(file_name,m,distance_error,iterations);

			// Run the K-Means algothm
			kmeans.start();

			// Write K-means output to a file
			kmeans.write2file();
		}
	}
}