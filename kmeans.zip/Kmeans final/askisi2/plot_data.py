import json
import matplotlib.pyplot as plt
import random as rd
from os import system

system("javac *.java")
system("java Main")

m=[3,5,7,9,11,13]
for k in m:
	filename="filename_"+str(k)+".json"
	f = open(filename)

	data = json.load(f)

	cm = plt.get_cmap('gist_rainbow')
	pm=[cm(1.*i/k) for i in range(k)]

	centers_x=[]
	centers_y=[]
	centers_c=[]

	points_x=[]
	points_y=[]
	points_c=[]

	counter=0
	for i in data:
		for j in i["group"]:
			points_x.append(j[0])
			points_y.append(j[1])
			points_c.append(pm[counter])

		centers_x.append(i["center"][0])
		centers_y.append(i["center"][1])
		centers_c.append(pm[counter])
		counter+=1

	plt.scatter(points_x,points_y,color=points_c,alpha=0.5,marker='+')
	plt.scatter(centers_x,centers_y,color=centers_c,marker=(5,2),s=200,linewidths=3)
	f.close()
	plt.title('K=%i' %k)
	plt.show()
