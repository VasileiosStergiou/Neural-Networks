import java.util.ArrayList;

class Center{

	public float [] position = new float[2];
	public float [] previous_position = {0.0f,0.0f};
	public ArrayList<float[]> group = new ArrayList<float[]>();

	public Center(float[] position){
		this.position[0] = position[0];
		this.position[1] = position[1];
	}

	public float [] get_position(){
		return position;
	}

	public void add_point(float[] point){
		this.group.add(point);
	}

	public void calculate_new_center(){
		float new_x = 0.0f;
		float new_y = 0.0f;

		this.previous_position[0] = position[0];
		this.previous_position[1] = position[1];

		for (float [] point : group){
			new_x += point[0];
			new_y += point[1];
		}

		if (group.size() != 0){
			this.position[0] = new_x/group.size();
			this.position[1] = new_y/group.size();
		}

	}

	public float get_distance(){

		float x = position[0] - previous_position[0];
		float y = position[1] - previous_position[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	public float get_error_distance(float [] point, float [] center){

		float x = point[0] - center[0];
		float y = point[1] - center[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	public float calculate_total_group_error(){
		float error = 0.0f;
		for (float [] point:group){
			error+= get_error_distance(point,position);
		}
		return error;
	}

	public void clear_group(){
		this.group = new ArrayList<float[]>();
	}
}