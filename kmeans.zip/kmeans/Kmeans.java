import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.ArrayList;
import java.util.Random;
import java.lang.Math;
import java.io.FileWriter;  // Write the File class
import java.io.IOException;  // Import the IOException class to handle errors

class Kmeans{
	public String filename;
	public int k;
	public float dist_error;
	public int iterations;

	public ArrayList<Center> best_centers = new ArrayList<Center>();
	
	public Kmeans(String filename,int k,float dist_error,int iterations){
		this.filename = filename;
		this.k = k;
		this.dist_error = dist_error; 
		this.iterations = iterations;
	}

	public void start() {
		ArrayList<float[]> data_set = parse_Data(filename);
		float best_score=Float.POSITIVE_INFINITY;
		float total_error=0.0f;
		int centers_moved;
		ArrayList<Center> centers;
		System.out.println("\nFOR K="+k);
		for (int iteration =0;iteration <20;iteration ++){
			centers = init_centers(k,data_set);
			centers_moved =1;

			while (centers_moved >0){
				for (Center c : centers){
					c.clear_group();
				}

				for (float[] point : data_set){
					
					float[] distances = new float[k];

					for (int i =0; i< k; i++){
						distances[i] = get_distance(point,centers.get(i).get_position());
					}
					centers.get(minValue(distances)).add_point(point);
				}

				centers_moved =0;
				for (Center c : centers){
					c.calculate_new_center();

					if (c.get_distance() >= dist_error){
						centers_moved+=1;
					}
				}
			}

			total_error=0.0f;
			for (Center c : centers){
				total_error += c.calculate_total_group_error();
			}

			System.out.println("ITERATION: "+(iteration+1)+" iteration Error="+total_error);

			if(total_error<best_score){
				best_score=total_error;
				best_centers=centers;
			}

		}
		System.out.println("Best score="+best_score);
		System.out.println("Best centers:");
		for(Center c:best_centers){
			System.out.println(c.position[0]+","+c.position[1]);
		}
		System.out.println("FINISHED");
	}

	public int minValue(float[] distances) {
		float min = distances[0];
		int pos = 0;
		for (int i = 0; i < distances.length; i++) {
				if (distances[i] < min) {
						min = distances[i];
						pos = i;
				}
		}
		return pos;
}

	public float get_distance(float [] point, float [] center){

		float x = point[0] - center[0];
		float y = point[1] - center[1];

		return (float) Math.sqrt(x*x + y*y);
	}

	public ArrayList<Center> init_centers(int k,ArrayList<float[]> data_set){

		ArrayList<Center> centers = new ArrayList<Center>();

		for (int i =0;i < k ;i++){
				Random random = new Random();
				int random_center = random.nextInt(data_set.size());
				centers.add(new Center(data_set.get(random_center)));
			}
			return centers;
	 }

	public ArrayList<float[]> parse_Data(String filename){
		ArrayList<float[]> all_data = new ArrayList<float[]>();
		float[] point;
		try {
			File myObj = new File(filename);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()) {
				point= new float[2];
				String[] data = myReader.nextLine().split(",");
				for(int i=0;i<2;i++){
					point[i]=Float.parseFloat(data[i]);
				}
				all_data.add(point);
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}  
		return all_data;
	}

	public void write2file(){
		try {
			FileWriter myWriter = new FileWriter("filename_"+k+".json");
			myWriter.write("[");
			String values="";
			for(Center center:best_centers){			
				values+="\n\t{\n";
				values+=" \t\t\"center\":";
				values+="["+center.get_position()[0]+","+center.get_position()[1]+"],\n";
				values+=" \t\t\"group\":";
				values+="[";
				for(float[] point: center.group){
					values+="["+point[0]+","+point[1]+"],";	
				}
				values = values.substring(0, values.length() - 1);
				values+="]\n";
				values+="\t},";
			}
			values = values.substring(0, values.length() - 1);
			values+="\n]";
			myWriter.write(values);
			myWriter.close();
			System.out.println("Successfully wrote to the file.");
		} catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
}