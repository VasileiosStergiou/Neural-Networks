class Main{
	public static void main(String[] args) {
		//int k=5;
		int[] k= {3,5,7,9,11,13};		
		String file_name="set2.txt";
		float distance_error=0.0001f;
		int iterations=20;

		for(int m:k){
			Kmeans kmeans = new Kmeans(file_name,m,distance_error,iterations);
			kmeans.start();
			kmeans.write2file();
		}
	}
}