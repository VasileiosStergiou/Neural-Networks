import json
import matplotlib.pyplot as plt
import random as rd

m=[3,5,7,9,11,13]
for k in m:
	filename="filename_"+str(k)+".json"
	f = open(filename)

	data = json.load(f)

	cm = plt.get_cmap('gist_rainbow')
	pm=[cm(1.*i/k) for i in range(k)]

	counter=0
	for i in data:
		for j in i["group"]:
			plt.scatter(j[0],j[1],color=pm[counter],marker='+')
		plt.scatter(i["center"][0],i["center"][1],color=pm[counter],marker='*',s=300)
		counter+=1

	f.close()
	plt.title('K=%i' %k)
	plt.show()
