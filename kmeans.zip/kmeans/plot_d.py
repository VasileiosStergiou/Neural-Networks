import matplotlib.pyplot as plt
f = open("set2.txt", "r")
data=f.read().split("\n")
new_data=[]
data=data[:-1]
for i in data:
	new_data.append([float(x) for x in i.split(",")])

for i in new_data:
	plt.scatter(i[0],i[1],color='blue')





f = open("kati.txt", "r")
data=f.read().split("\n")
centers=[]
print(data)
for i in data:
	centers.append([float(x) for x in i.split(",")])

x_s=[]
y_s=[]
for i in centers:
	#x_s.append(i[0])
	#y_s.append(i[1])
	plt.scatter(i[0],i[1],color='red')

plt.show()
